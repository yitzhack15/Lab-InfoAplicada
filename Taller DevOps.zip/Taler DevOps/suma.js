function suma(a,b){
    return parseInt(a) + parseInt(b);
}

module.exports = suma;